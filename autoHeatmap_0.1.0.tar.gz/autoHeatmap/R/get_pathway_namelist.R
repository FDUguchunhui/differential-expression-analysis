.libPaths("D:/R-3.5.1/library")
#' @import tidyverse xlsx pheatmap gplots
# options
options(tibble.print_max = 10, tibble.width = Inf)

#' plot heatmap by integrate data from DESeq and enrichment analysis
#'
#' more information
#' @param fileName is the post-processed Excel file from enrichment analysis
#' @return a list of tibbles of external gene names from different enrichment pathway
#' @export
get_pathway_namelist <- function(fileName){

  #read the enrichment dataset as tibble
  enrichment.tibble <- read.xlsx(file = fileName, sheetIndex =1, startRow = 3, header = T,
                                 stringsAsFactors = F) %>% as_tibble()
  # the enrichment.table have data structure like this
  # Entrez.Gene.Id Gene.Symbol Gene.Description                               HALLMARK_E2F_TARGETS
  # <dbl> <fct>       <fct>                                          <fct>
  #   1           7153 TOP2A       topoisomerase (DNA) II alpha 170kDa            HALLMARK_E2F_TARGETS
  # 2            991 CDC20       cell division cycle 20 homolog (S. cerevisiae) HALLMARK_E2F_TARGETS
  # 3          10733 PLK4        polo-like kinase 4                             HALLMARK_E2F_TARGETS
  # 4           6790 AURKA       aurora kinase A                                HALLMARK_E2F_TARGETS
  # 5           5347 PLK1        polo-like kinase 1                             HALLMARK_E2F_TARGETS
  # 6            983 CDK1        cyclin-dependent kinase 1                      HALLMARK_E2F_TARGETS
  # 7            332 BIRC5       baculoviral IAP repeat containing 5            HALLMARK_E2F_TARGETS
  # 8          11004 KIF2C       kinesin family member 2C                       HALLMARK_E2F_TARGETS
  # 9           9133 CCNB2       cyclin B2                                      HALLMARK_E2F_TARGETS
  # 10          24137 KIF4A       kinesin family member 4A                       HALLMARK_E2F_TARGETS

  # create a number of list corresponding to the number pathway in the enrichment analysis
  pathway_names.vector <- colnames(enrichment.tibble)[-c(1:3)]
  pathway_genes.list <- list()
  for(i in 1:length(pathway_names.vector)){
    pathway_genes.list[[i]] <- dplyr::select(enrichment.tibble, `Gene.Symbol`,
                                        pathway_names.vector[i]) %>%
      filter(.[[2]] != 'NA')
  }

  # assign the pathway name to each subset on the list
  names(pathway_genes.list) <- pathway_names.vector

  return(pathway_genes.list)
}

#' get tibbles of different subgrouped genes by pathway
#'
#' more information
#' @param count_matrix  the RNA-seq expression level count matrix
#' @param enrichment_xlsx  the modified enrichment export xlsx file
#' @param fun the fun used to get lists of genes names from enrichment analysis
#'  export
#' @return a list of tibbles of count matrix for different pathways
#' @export
#'
#'
subset_count_maxtrix <- function(count_matrix, enrichment_xlsx){
  # convert count matrix as tibble
  count_matrix.tibble <- as_tibble((data.frame(gene_name = row.names(count_matrix),
                                                                 count_matrix)))
  pathway_genes <- get_pathway_namelist(enrichment_xlsx)
  # get a list of lists of gene names only
  pathway_genes_names.list <- lapply(pathway_genes, FUN = pull, 1)
  # use the lists of gene to subset the count matrix
  # initialize the subgroup
  count_matrix_subgrouped.list <- list()
  # get a list of those subgroup genes sets
  for(i in 1:length(pathway_genes_names.list)){
    count_matrix_subgrouped.list[[i]] <-
      dplyr::filter(count_matrix.tibble, gene_name %in% pathway_genes_names.list[[i]])
  }
  result_list <- list('subgroups' = count_matrix_subgrouped.list, 'names' = pathway_genes_names.list)
  return(result_list)
}



#' plot heatmap by integrate data from DESeq and enrichment analysis
#'
#' more information
#' @param count_matrix the RNA-seq expression level count matrix
#' @param enrichment_xlsx the post-processed Excel file from enrichment analysis
#' @return a list of tibbles of external gene names from different enrichment pathway
#' @export
#'
#'
hmplot <- function(count_matrix, enrichment_xlsx){
  # get the a list of tibbles of subsets of genes
  genes_tibbles.list <- subset_count_maxtrix(count_matrix, enrichment_xlsx)$subgroups
  # get the names of objects in list, will be used as title of heatmaps
  pathway_names <- names(subset_count_maxtrix(count_matrix, enrichment_xlsx)$names)
  # transform tibbles into count_matrices with first column as rownames
  genes_pre_matrices.list <- lapply(genes_tibbles.list, select, -1)
  genes_count_matrices.list <- lapply(genes_pre_matrices.list, data.matrix)
  for(i in 1:length(genes_tibbles.list)){
    rownames(genes_count_matrices.list[[i]]) <- pull(select(genes_tibbles.list[[i]], 1))
  }
  # plot the heatmap for subsets
  for(i in 1:length(genes_tibbles.list)){
     #heatmap(genes_count_matrices.list[[i]], main = pathway_names[i], Rowv = F)
     #heatmap.2(genes_count_matrices.list[[i]], main = pathway_names[i], Rowv = F)
     pheatmap(genes_count_matrices.list[[i]], main = pathway_names[i], cluster_cols = F)
  }
}



