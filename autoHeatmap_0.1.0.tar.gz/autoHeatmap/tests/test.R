library(tidyverse)
count_matrix <- read.csv(file = 'data/count_matrix.csv')
row.names(count_matrix) <- count_matrix[,'X']
count_matrix <- count_matrix[, -1]

# get_pathway_namelist('data/example.xlsx')
 subset_count_maxtrix(count_matrix , 'data/example.xlsx')
# #
hmplot(count_matrix , 'data/example.xlsx')

